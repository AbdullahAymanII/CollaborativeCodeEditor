package com.collaborative.editor.model.mongodb;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "comments")
public class Comment {

    private Long roomId;

    private String projectName;  // User ID

    private Long fileVersion;  // Reference to FileVersion in MongoDB

    private Long lineNumber;  // Line number where the comment is made

    private String viewerEmail;  // User email

    private String content;  // Content of the comment

}
