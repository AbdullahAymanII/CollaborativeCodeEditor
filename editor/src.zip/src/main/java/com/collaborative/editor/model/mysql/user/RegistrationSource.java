package com.collaborative.editor.model.mysql.user;

public enum RegistrationSource {
    GITHUB,
    GOOGLE,
}