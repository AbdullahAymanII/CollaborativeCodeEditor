package com.collaborative.editor.model.mysql.room;

public enum RoomRole {
    OWNER,
    COLLABORATOR,
    VIEWER
}
